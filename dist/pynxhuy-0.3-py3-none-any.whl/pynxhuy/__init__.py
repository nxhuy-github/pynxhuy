from .modules import joke, hugeJoke

def hugeHugeJoke():
    print(joke())
    print(hugeJoke())
