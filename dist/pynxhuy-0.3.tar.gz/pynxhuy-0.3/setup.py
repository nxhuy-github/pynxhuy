from setuptools import setup

setup(name='pynxhuy',
      version='0.3',
      description='The nxhuyiest joke in the world',
      url='https://github.com/nxhuy-github/pynxhuy',
      author='Xuan Huy NGUYEN',
      author_email='nxhuy@example.com',
      packages=['pynxhuy'],
      zip_safe=False)
