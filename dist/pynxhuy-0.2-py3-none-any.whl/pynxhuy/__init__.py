from .modules import joke, hugeJoke

def hugeHugeJoke():
    joke()
    hugeJoke()
